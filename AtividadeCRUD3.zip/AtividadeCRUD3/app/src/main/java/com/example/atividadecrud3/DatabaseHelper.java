package com.example.atividadecrud3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    //Cria o banco de dados
    public static final String DATABASE_NAME = "Banco3.db";
    public static final String TABLE_NAME = "jogo_table";
    public static final String COL1 = "ID";
    public static final String COL2 = "TITULO";
    public static final String COL3 = "GENERO";
    public static final String COL4 = "PRECO";


    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
       // SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//cria a tabela
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, TITULO TEXT, GENERO TEXT, PRECO TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//Deleta uma tabela se ela ja existir e a cria novamente
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }

   public boolean inserirDados (String titulo, String genero, String preco){
        //insere um registro na tabela e checa se foi salvo
       SQLiteDatabase db = this.getWritableDatabase();
       ContentValues contentValues = new ContentValues();
       contentValues.put(COL2, titulo);
       contentValues.put(COL3, genero);
       contentValues.put(COL4, preco);
       long result = db.insert(TABLE_NAME,null, contentValues);

       if(result == -1)
           return false;
       else
           return true;
    }

    public Cursor verDados(){
        //Metodo para listar o registros
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }

    public boolean atualizar(String id, String titulo, String genero, String preco){
        //Metodo para atualizar o registro onde o campo for Compativel com o campo ID
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, id);
        contentValues.put(COL2, titulo);
        contentValues.put(COL3, genero);
        contentValues.put(COL4, preco);
        db.update(TABLE_NAME,contentValues, "id = ?", new String[] {id});
        return true;
    }

    public Integer deletarDados (String id){
        //Metodo que delata os dados onde for compativel com o campo id
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "ID = ?", new String[]{id});
    }


}
