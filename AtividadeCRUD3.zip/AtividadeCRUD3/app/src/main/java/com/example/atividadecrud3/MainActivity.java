package com.example.atividadecrud3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Cria as variaveis para serem relacionadas com a activity main
    DatabaseHelper myDb;
    EditText editTitulo,editGenero,editPreco, editId;
    Button btnSalvar;
    Button btnVerDados;
    Button btnAtualizar;
    Button btnDeletar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //relaciona com o banco de dados
        myDb = new DatabaseHelper(this);
        //relaciona com os campos da layout activity main
        editTitulo = (EditText)findViewById(R.id.editText_titulo);
        editGenero = (EditText)findViewById(R.id.editText_genero);
        editPreco = (EditText)findViewById(R.id.editText_preco);
        editId = (EditText)findViewById(R.id.editText_id);
        btnSalvar = (Button)findViewById(R.id.button_salvar);
        btnVerDados = (Button)findViewById(R.id.button_ver);
        btnAtualizar = (Button)findViewById(R.id.button_atualizar);
        btnDeletar  = (Button)findViewById(R.id.button_deletar);
        //Metodos da Activity main
        SalvarDados();
        VerTodosDados();
        AtualizarDados();
        DeletarDados();



    }


    public void DeletarDados(){
        //metodo do botão deletar
        btnDeletar.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = myDb.deletarDados(editId.getText().toString());
                        if(deletedRows > 0)
                            Toast.makeText(MainActivity.this,"Dado Deletado",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Os Dados não Foram Deletados",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void AtualizarDados(){
        //metodo do botão atualizar
        btnAtualizar.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isUpdate = myDb.atualizar(editId.getText().toString(), editTitulo.getText().toString(), editGenero.getText().toString(), editPreco.getText().toString());

                        if(isUpdate == true)
                            Toast.makeText(MainActivity.this,"Dado Atualizado",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Os Dados não Foram Atualizados",Toast.LENGTH_LONG).show();

                    }
                }

        );
    }

    public void SalvarDados(){
        //metodo do botao salvar
        btnSalvar.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.inserirDados(editTitulo.getText().toString(), editGenero.getText().toString(), editPreco.getText().toString());
                        if(isInserted=true)
                            Toast.makeText(MainActivity.this,"Dados Salvos",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Os Dados não Foram Salvos",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void VerTodosDados(){
        //metodo do botão listar
        btnVerDados.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.verDados();
                        if(res.getCount()== 0){
                            mensagem("Erro","Nenhum Dado Cadastrado");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()){
                            buffer.append("id: "+ res.getString(0)+"\n");
                            buffer.append("titulo "+ res.getString(1)+"\n");
                            buffer.append("genero "+ res.getString(2)+"\n");
                            buffer.append("preco "+ res.getString(3)+"\n\n");
                        }
                        //Mostrar Todos Os Dados
                        mensagem("Dados",buffer.toString());

                    }
                }
        );
    }

    public void mensagem(String title, String Message){
        //contrutor da mensagem de erro das telas
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }





}
